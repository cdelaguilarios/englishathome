<?php

namespace App\Helpers\Enum;

class TiposRelacionEntidad {

  const AlumnoInteresado = "ALUMNO-INTERESADO";

}
