<?php

namespace App\Http\Controllers;

use Log;
use Crypt;
use Mensajes;
use Datatables;
use App\Models\Clase;
use App\Models\Alumno;
use App\Models\Docente;
use App\Models\PagoAlumno;
use App\Models\Interesado;
use App\Http\Controllers\Controller;
use App\Http\Requests\Alumno\BusquedaRequest;
use App\Http\Requests\Alumno\FormularioRequest;
use App\Http\Requests\Alumno\ActualizarEstadoRequest;
use App\Http\Requests\Alumno\ActualizarHorarioRequest;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Requests\Alumno\Pago as PagoRequest;
use App\Http\Requests\Alumno\Clase as ClaseRequest;

class AlumnoController extends Controller {

  protected $data = array();

  public function __construct() {
    $this->data["seccion"] = "alumnos";
  }

  // <editor-fold desc="Alumno">
  public function index() {
    return view("alumno.lista", $this->data);
  }

  public function listar(BusquedaRequest $req) {
    return Datatables::of(Alumno::listar($req->all()))->filterColumn("entidad.nombre", function($q, $k) {
              $q->whereRaw('CONCAT(entidad.nombre, " ", entidad.apellido) like ?', ["%{$k}%"]);
            })->make(true);
  }

  public function crear() {
    return view("alumno.crear", $this->data);
  }

  public function registrar(FormularioRequest $req) {
    try {
      $idAlumno = Alumno::registrar($req);
      Mensajes::agregarMensajeExitoso("Registro exitoso.");
      return redirect(route("alumnos.perfil", ["id" => $idAlumno]));
    } catch (\Exception $e) {
      Log::error($e);
      Mensajes::agregarMensajeError("Ocurrió un problema durante el registro de datos. Por favor inténtelo nuevamente.");
      return redirect(route("alumnos.crear"));
    }
  }

  public function crearExterno($codigoVerificacion) {
    try {
      $this->data["vistaExterna"] = TRUE;
      $this->data["codigoVerificacion"] = $codigoVerificacion;
      $this->data["interesado"] = Interesado::obtenerXId(Crypt::decrypt($codigoVerificacion));
      return view("alumno.crear", $this->data);
    } catch (\Exception $e) {
      Log::error($e);
      abort(404);
    }
  }

  public function registrarExterno(FormularioRequest $req) {
    try {
      $datos = $req->all();
      Alumno::registrarExterno($req);
    } catch (\Exception $e) {
      Log::error($e);
      Mensajes::agregarMensajeError("Ocurrió un problema durante el registro de datos. Por favor inténtelo nuevamente.");
    }
    return redirect(route("alumnos.crear.externo", ["codigoVerificacion" => $datos["codigoVerificacion"]]));
  }

  public function perfil($id) {
    try {
      $this->data["alumno"] = Alumno::obtenerXId($id);
    } catch (ModelNotFoundException $e) {
      Log::error($e);
      Mensajes::agregarMensajeError("No se encontraron datos del alumno seleccionado.");
      return redirect(route("alumnos"));
    }
    return view("alumno.perfil", $this->data);
  }

  public function editar($id) {
    try {
      $this->data["alumno"] = Alumno::obtenerXId($id);
    } catch (ModelNotFoundException $e) {
      Log::error($e);
      Mensajes::agregarMensajeError("No se encontraron datos del alumno seleccionado.");
      return redirect(route("alumnos"));
    }
    return view("alumno.editar", $this->data);
  }

  public function actualizar($id, FormularioRequest $req) {
    try {
      Alumno::actualizar($id, $req);
      Mensajes::agregarMensajeExitoso("Actualización exitosa.");
    } catch (\Exception $e) {
      Log::error($e->getMessage());
      Mensajes::agregarMensajeError("Ocurrió un problema durante la actualización de datos. Por favor inténtelo nuevamente.");
    }
    return redirect(route("alumnos.editar", ["id" => $id]));
  }

  public function actualizarEstado($id, ActualizarEstadoRequest $req) {
    try {
      $datos = $req->all();
      Alumno::actualizarEstado($id, $datos["estado"]);
    } catch (ModelNotFoundException $e) {
      Log::error($e);
      return response()->json(["mensaje" => "Ocurrió un problema durante la actualización de datos. Por favor inténtelo nuevamente."], 400);
    }
    return response()->json(["mensaje" => "Actualización exitosa."], 200);
  }

  public function actualizarHorario($id, ActualizarHorarioRequest $req) {
    try {
      $datos = $req->all();
      Alumno::actualizarHorario($id, $datos["horario"]);
    } catch (ModelNotFoundException $e) {
      Log::error($e);
      return response()->json(["mensaje" => "Ocurrió un problema durante la actualización de datos. Por favor inténtelo nuevamente."], 400);
    }
    return response()->json(["mensaje" => "Actualización exitosa."], 200);
  }

  public function eliminar($id) {
    try {
      Alumno::eliminar($id);
    } catch (ModelNotFoundException $e) {
      Log::error($e);
      return response()->json(["mensaje" => "No se pudo eliminar el registro de datos del alumno seleccionado."], 400);
    }
    return response()->json(["mensaje" => "Eliminación exitosa", "id" => $id], 200);
  }

  // </editor-fold>
  // <editor-fold desc="Pagos">
  public function listarPagos($id) {
    return Datatables::of(PagoAlumno::listar($id))->make(true);
  }

  public function actualizarEstadoPago($id, PagoRequest\ActualizarEstadoRequest $req) {
    try {
      PagoAlumno::actualizarEstado($id, $req->all());
    } catch (ModelNotFoundException $e) {
      Log::error($e);
      return response()->json(["mensaje" => "Ocurrió un problema durante la actualización de datos. Por favor inténtelo nuevamente."], 400);
    }
    return response()->json(["mensaje" => "Actualización exitosa."], 200);
  }

  public function generarClasesXPago($id, PagoRequest\GenerarClasesRequest $req) {
    return response()->json(Clase::generarXDatosPago($id, $req->all()), 200);
  }

  public function listarDocentesDisponiblesXPago($id, PagoRequest\ListarDocentesDisponiblesRequest $req) {
    return Datatables::of(Docente::listarDisponiblesXDatosPago($id, $req->all()))
                    ->filterColumn("nombreCompleto", function($q, $k) {
                      $q->whereRaw('CONCAT(entidad.nombre, " ", entidad.apellido) like ?', ["%{$k}%"]);
                    })->make(true);
  }

  public function registrarPago($id, PagoRequest\FormularioRequest $req) {
    try {
      PagoAlumno::registrar($id, $req);
      Mensajes::agregarMensajeExitoso("Registro exitoso.");
    } catch (\Exception $e) {
      Log::error($e);
      Mensajes::agregarMensajeError("Ocurrió un problema durante el registro de datos. Por favor inténtelo nuevamente.");
    }
    return redirect(route("alumnos.perfil", ["id" => $id, "sec" => "pago"]));
  }

  public function datosPago($id, $idPago) {
    return response()->json(PagoAlumno::obtenerXId($id, $idPago), 200);
  }

  public function eliminarPago($id, $idPago) {
    try {
      PagoAlumno::eliminar($id, $idPago);
    } catch (ModelNotFoundException $e) {
      Log::error($e);
      return response()->json(["mensaje" => "No se pudo eliminar el registro de datos del pago seleccionado."], 400);
    }
    return response()->json(["mensaje" => "Eliminación exitosa", "id" => $idPago], 200);
  }

  // </editor-fold>
  // <editor-fold desc="Clases">
  public function listarPeriodosClases($id) {
    return Datatables::of(Clase::listarPeriodos($id))->make(true);
  }

  public function listarClases($id, $numeroPeriodo) {
    return response()->json(Clase::listarXAlumno($id, $numeroPeriodo), 200);
  }

  public function actualizarEstadoClase($id, ClaseRequest\ActualizarEstadoRequest $req) {
    try {
      Clase::actualizarEstado($id, $req->all());
    } catch (ModelNotFoundException $e) {
      Log::error($e);
      return response()->json(["mensaje" => "Ocurrió un problema durante la actualización de datos. Por favor inténtelo nuevamente."], 400);
    }
    return response()->json(["mensaje" => "Actualización exitosa."], 200);
  }

  public function listarDocentesDisponiblesXClase($id, ClaseRequest\ListarDocentesDisponiblesRequest $req) {
    return Datatables::of(Docente::listarDisponiblesXDatosClase($req->all()))
                    ->filterColumn('nombreCompleto', function($q, $k) {
                      $q->whereRaw('CONCAT(entidad.nombre, " ", entidad.apellido) like ?', ["%{$k}%"]);
                    })->make(true);
  }

  public function registrarActualizarClase($id, ClaseRequest\FormularioRequest $req) {
    try {
      $datos = $req->all();
      Clase::registrarActualizar($id, $datos);
      Mensajes::agregarMensajeExitoso(isset($datos["idClase"]) ? "Registro exitoso." : "Actualización exitosa.");
    } catch (\Exception $e) {
      Log::error($e);
      Mensajes::agregarMensajeError("Ocurrió un problema durante el registro/actualización de datos. Por favor inténtelo nuevamente.");
    }
    return redirect(route("alumnos.perfil", ["id" => $id, "sec" => "clase"]));
  }

  public function cancelarClase($id, ClaseRequest\CancelarRequest $req) {
    try {
      $datos = $req->all();
      Clase::cancelar($id, $datos);
      Mensajes::agregarMensajeExitoso("Cancelación exitosa.");
    } catch (\Exception $e) {
      Log::error($e);
      Mensajes::agregarMensajeError("No se pudo cancelar la clase seleccionada.");
    }
    return redirect(route("alumnos.perfil", ["id" => $id, "sec" => "clase"]));
  }

  public function datosClase($id, $idClase) {
    return response()->json(Clase::obtenerXId($id, $idClase), 200);
  }

  public function eliminarClase($id, $idClase) {
    try {
      Clase::eliminar($id, $idClase);
    } catch (ModelNotFoundException $e) {
      Log::error($e);
      return response()->json(["mensaje" => "No se pudo eliminar el registro de datos de la clase seleccionada."], 400);
    }
    return response()->json(["mensaje" => "Eliminación exitosa", "id" => $idClase], 200);
  }

  // </editor-fold>
}
